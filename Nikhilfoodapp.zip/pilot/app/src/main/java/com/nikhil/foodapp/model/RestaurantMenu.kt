package com.nikhil.foodapp.model

class RestaurantMenu (
    var id:String,
    var name:String,
    var cost_for_one:String
)